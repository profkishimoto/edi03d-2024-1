//
// Ciência da Computação - Estrutura de Dados I
// Palindromo (Verificador de palíndromos)
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

public class Palindromo {

	private String texto;

	Palindromo() {
		this("");
	}

	Palindromo(String texto) {
		setTexto(texto);
	}

	// Sobrescrita/sobreposição (override) do método toString(), que veio da superclasse Object.
	// O retorno do método toString() é a representação de um objeto em formato string, e toString()
	// geralmente é executado (de forma implícita) quando passamos um objeto ao System.out.print*().
	//
	// Experimente incluir o seguinte código na main() e veja a saída:
	// Palindromo p = new Palindromo();
	// System.out.println(p);
	//
	// Depois, remova/comente o método toString() abaixo e rode o código acima novamente.
	@Override
	public String toString() {
		return texto;
	}
	
	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		// Caso o parâmetro texto receba o valor null (um valor inválido, de acordo com
		// a especificação da classe), lançamos uma exceção do tipo
		// IllegalArgumentException ("exceção do tipo argumento ilegal"), que pode
		// ser tratada com um try-catch no trecho de código que faz a chamada à
		// setTexto().
		if (texto == null)
			throw new IllegalArgumentException("setTexto(String texto): Parâmetro texto não pode ser null.");

		this.texto = texto;
	}

	public boolean verificar() {
		boolean resultado = true;

		//char c[] = StringUtils.removeWhitespace(texto).toLowerCase().toCharArray();
		char c[] = MyStringUtils.keepRegularLettersOnly(texto).toLowerCase().toCharArray();

		// Para verificar se o texto é um palíndromo, verificamos se o primeiro
		// caractere é igual ao último, se o segundo é igual ao penúltimo, e
		// assim por diante.
		//
		// Portanto, podemos usar um loop que itera apenas metade da string,
		// pois em uma iteração já estamos verificando as duas extremidades da
		// string.
		//
		// Observe que, caso a quantidade de caracteres da string seja um número
		// ímpar, podemos ignorar o caractere que divide a string em duas partes,
		// já que tal caractere está bem no ponto de espelhamento do palíndromo.
		int tamanho = c.length;
		int metade = tamanho >> 1;
		int indiceInvertido = 0;
		for (int i = 0; i < metade; ++i) {
			indiceInvertido = tamanho - 1 - i;

			// Se já descobrimos que a string não é um palíndromo, podemos
			// encerrar o loop antecipadamente.
			if (c[i] != c[indiceInvertido]) {
				resultado = false;
				break;
			}

			// Descomente a linha a seguir caso queira ver na saída do console os índices
			// e elementos comparados em cada iteração do loop.
			//System.out.println(i + "=" + c[i] + "..." + c[indiceInvertido] + "=" + indiceInvertido);
		}

		return resultado;
	}

}
