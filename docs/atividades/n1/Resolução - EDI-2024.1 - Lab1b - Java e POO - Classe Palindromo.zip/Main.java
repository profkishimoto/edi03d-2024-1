//
// Ciência da Computação - Estrutura de Dados I
// Palindromo (Testes para verificação de palíndromos)
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

import java.util.Scanner;

public class Main {
	
	public static void testes() {
		String[] frases = {
			"",
			"MuSsUm",
			"A Sacada da Casa",
			"Bolton",
			"Hello World",
			"Olá, Galo!",
			"	áéíóú ç      ÛÔÎÊÂ   ",
		};
		
		System.out.println("----------[ TESTES : INÍCIO ]----------");

		Palindromo palindromo = new Palindromo();
		for (var frase : frases) {
			palindromo.setTexto(frase);
			System.out.println("\"" + palindromo + "\" ==> Palíndromo? " + palindromo.verificar());
		}
		
		System.out.println("----------[ TESTES : FIM ]----------\n");
	}

	public static void main(String[] args) {
		testes();
		
		Scanner s = new Scanner(System.in);
		
		String str = "";
		Palindromo p = new Palindromo();

		for (;;) {
			System.out.println("Digite um texto qualquer (/sair para encerrar): ");
			str = s.nextLine();
			
			if (str.equalsIgnoreCase("/sair"))
				break;

			p.setTexto(str);
			System.out.println("\"" + p + "\" ==> Palíndromo? " + p.verificar());
		}
		
		System.out.println("Fim.");
	}

}
