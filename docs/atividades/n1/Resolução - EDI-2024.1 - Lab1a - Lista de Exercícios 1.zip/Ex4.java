//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 4
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 4. Escreva um código Java que leia 10 números inteiros e, em seguida, exiba-os
 * na ordem inversa que foram inseridas pelo usuário.
 */

import java.util.Scanner;

public class Ex4 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		final int QUANTIDADE_NUMEROS = 10;
		int numeros[] = new int[QUANTIDADE_NUMEROS];

		for (int i = 0; i < QUANTIDADE_NUMEROS; ++i) {
			System.out.print("Digite um número (" + (i + 1) + "): ");
			numeros[i] = s.nextInt();
		}

		// Observe que o enunciado não pediu para ordenar o vetor, apenas para
		// exibir os número na ordem inversa que foram inseridas. Portanto, esse segundo
		// loop for é feito do final para o início.
		for (int i = QUANTIDADE_NUMEROS - 1; i >= 0; --i) {
			System.out.println(numeros[i]);
		}

		s.close();
	}

}
