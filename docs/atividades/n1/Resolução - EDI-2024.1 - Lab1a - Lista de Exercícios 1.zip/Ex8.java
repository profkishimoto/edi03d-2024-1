//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 8
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 8. Dois círculos se sobrepõem (colidem) se a soma dos seus raios é maior que ou
 * igual a distância entre seus centros. A distância entre dois pontos pode ser
 * calculada usando o teorema de Pitágoras (c = √𝑎2 + 𝑏2). Escreva um método
 * estático haColisaoEntreCirculos() que recebe seis parâmetros: a posição
 * p1(x,y) e o raio r1 do primeiro círculo e a posição p2(x,y) e o raio r2 do segundo
 * círculo. Com os parâmetros informados, a função deve retornar true caso os
 * círculos estejam sobrepostos ou false, caso contrário.
 * 
 * Inclua um código na main() que exemplifica o uso do método haColisaoEntreCirculos().
 */

import java.util.Scanner;

public class Ex8 {
	
	public static boolean haColisaoEntreCirculos(float x1, float y1, float r1, float x2, float y2, float r2) {
		float a = x1 - x2;
		float b = y1 - y2;
		float c = a * a + b * b;
		float somaDosRaios = r1 + r2;
		
		// Truque de otimização: ao invés de calcularmos a raiz quadrada no teorema de
		// Pitágoras, comparamos ambos os lados "como se cada lado estivesse dentro de
		// uma raiz quadrada".
		//
		// O código seguindo o enunciado seria:
		// return somaDosRaios >= sqrt(a^2 + b^2);
		//
		// Mas veja que sqrt(somaDosRaios^2) é igual à somaDosRaios. Então podemos
		// escrever:
		// return sqrt(somaDosRaios^2) >= sqrt(a^2 + b^2);
		//
		// E, assim, comparar apenas os valores que estão dentro da raiz quadrada,
		// obtendo:
		return somaDosRaios * somaDosRaios >= c;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("Informe a coordenada X do círculo 1: ");
		float x1 = s.nextFloat();
		System.out.print("Informe a coordenada Y do círculo 1: ");
		float y1 = s.nextFloat();
		System.out.print("Informe o raio do círculo 1: ");
		float r1 = s.nextFloat();
		
		System.out.print("Informe a coordenada X do círculo 2: ");
		float x2 = s.nextFloat();
		System.out.print("Informe a coordenada Y do círculo 2: ");
		float y2 = s.nextFloat();
		System.out.print("Informe o raio do círculo 2: ");
		float r2 = s.nextFloat();
		
		boolean haColisao = haColisaoEntreCirculos(x1, y1, r1, x2, y2, r2);
		
		System.out.println("Os círculos C1(" + x1 + ", " + y1 + ") com raio " + r1
				+ " e C2(" + x2 + ", " + y2 + ") com raio " + r2
				+ (haColisao ? " " : " não ") + "estão sobrepostos."); 
		
		s.close();
	}

}
