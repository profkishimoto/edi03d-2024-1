//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 6
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 6. Escreva um método estático mulComAdicao() que recebe dois números como
 * parâmetros. O primeiro parâmetro é um número real e o segundo parâmetro um
 * número inteiro. A função deve retornar a multiplicação entre os parâmetros,
 * porém, a multiplicação deve ser feita usando apenas a operação de adição.
 * 
 * Inclua um código na main() que exemplifica o uso do método mulComAdicao().
 */

import java.util.Scanner;

public class Ex6 {

	public static float mulComAdicao(float multiplicando, int multiplicador) {
		int quantidade = Math.abs(multiplicador);
		float resultado = 0.0f;
		for (int i = 0; i < quantidade; ++i) {
			resultado += multiplicando;
		}
		return multiplicador < 0 ? -resultado : resultado;
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.print("Informe um número real: ");
		float multiplicando = s.nextFloat();
		
		System.out.print("Informe um número inteiro: ");
		int multiplicador = s.nextInt();
		
		float resultado = mulComAdicao(multiplicando, multiplicador);
		System.out.println(multiplicando + " * " + multiplicador + " = " + resultado);

		s.close();
	}

}
