//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 3
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 3. Escreva um código Java que leia 10 números reais e, após a leitura
 * dos números, informe qual é o maior e qual é o menor.
 */

import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		final int QUANTIDADE_NUMEROS = 10;

		// Definimos o menor número float para a variável maior e o maior número float
		// para a variável menor, para que as comparações com o primeiro número
		// informado pelo usuário sejam realizadas corretamente.
		float maior = Float.MIN_VALUE;
		float menor = Float.MAX_VALUE;

		float numero = 0;
		int contador = 0;

		while (contador < QUANTIDADE_NUMEROS) {
			System.out.print("Digite um número (" + (contador + 1) + "): ");
			numero = s.nextFloat();

			if (numero > maior)
				maior = numero;

			if (numero < menor)
				menor = numero;

			++contador;
		}

		System.out.println("Menor número é " + menor + " e maior número é " + maior + ".");

		s.close();
	}

}
