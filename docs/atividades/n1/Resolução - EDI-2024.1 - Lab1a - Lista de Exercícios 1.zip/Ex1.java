//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 1
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 1. Escreva um código Java que leia dois números inteiros informados pelo
 * usuário. Cada número deve ser salvo em variáveis distintas, por exemplo,
 * valor1 e valor2. Após ler os dois números, o código deve trocar o conteúdo
 * das variáveis.
 * 
 * Exemplo: valor1 armazena o número 30 e valor2 armazena o número 50.
 * Após o algoritmo ser executado, a variável valor1 deve armazenar o
 * número 50 e a variável valor2 deve armazenar o número 30.
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		// Scanner é usado para entrada de dados via teclado (System.in).
		Scanner s = new Scanner(System.in);

		// s.nextInt() assume que o conteúdo que a pessoa digita é um número inteiro.
		// Porém, a pessoa pode inserir algo que não seja um número inteiro (uma
		// palavra, por exemplo).
		// Nesse caso, temos um problema: estou tentando salvar um valor que não é
		// número inteiro na variável valor1, que é do tipo int.
		// Caso isso aconteça, s.nextInt() lança uma exceção (erro). Quando uma
		// instrução lança uma exceção, podemos tratá-la com o try-catch (podemos ler o
		// try-catch como "tente fazer isso, se não der certo, capture a exceção").
		// Então, o código a seguir pode ser lido como:
		// Tente (try) ler um número inteiro informado pelo usuário. Se o usuário
		// informar um número inteiro, salve na variável valor1 e continue a execução do
		// código. Mas, se a tentativa de ler o número inteiro falhar, muito
		// provavelmente porque o usuário informou um valor que não é um número inteiro,
		// então trate (catch) esse problema de forma que o programa não quebre.
		// Nesse exemplo, exibimos uma mensagem na tela e simplesmente escolhemos
		// atribuir zero para valor1.
		// Poderíamos encerrar o programa antecipadamente.
		// Outra sugestão que apareceu em aula é de fazer esse trecho de código em um
		// loop, pedindo para a pessoa informar valor1 de forma correta (isto é, o loop
		// continua enquanto um número inteiro não é informado).
		int valor1;
		try {
			System.out.print("valor1: ");
			valor1 = s.nextInt();
		} catch (InputMismatchException ex) {
			// Observe que usamos System.err ao invés de System.out. Geralmente a saída do
			// System.err é a mesma do System.out (ex. terminal), mas podemos redirecionar
			// para saídas diferentes (ex. System.out para terminal e System.err para
			// arquivo).
			System.err.println("O valor informado não é um número válido.");
			valor1 = 0;

			// s.nextInt() só "consome" o número inteiro e deixa a quebra de linha que é
			// inserida quando a pessoa aperta a tecla <enter> para terminar a entrada de
			// dados no programa. Por conta disso, é muito comum incluirmos uma chamada
			// s.nextLine() para remover a quebra de linha deixada pelo s.nextInt().
			// Observe que não salvamos o retorno de s.nextLine() em nenhum lugar - queremos
			// simplesmente descartar a quebra de linha do buffer de entrada de dados do
			// usuário.
			s.nextLine();
		}

		// Bem parecido com a leitura do valor1 acima. A diferença é que já atribuímos
		// zero para a variável valor2.
		// Dessa maneira, caso o código entre no catch, só mostramos a mensagem de erro
		// e valor2 já tem o valor zero.
		int valor2 = 0;
		try {
			System.out.print("valor2: ");
			valor2 = s.nextInt();
		} catch (InputMismatchException ex) {
			System.err.println("O valor informado não é um número válido.");
			s.nextLine();
		}

		// Troca dos valores das variáveis e exibição do resultado final.
		int temp = valor1;
		valor1 = valor2;
		valor2 = temp;

		System.out.println("novo valor1: " + valor1 + "\nnovo valor2: " + valor2);

		// Fechamos o Scanner pois já finalizamos a leitura de entrada de dados via
		// teclado.
		s.close();
	}

}
