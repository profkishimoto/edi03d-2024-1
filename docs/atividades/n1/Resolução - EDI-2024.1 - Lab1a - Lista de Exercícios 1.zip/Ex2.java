//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 2
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 2. Escreva um código Java que leia uma letra e indique se é uma vogal
 * ou consoante.
 */

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.print("Digite uma letra: ");

		// Como a classe Scanner não possui um método nextChar(), apenas next() que
		// obtém uma string, precisamos obter uma string e considerar apenas o primeiro
		// caractere.
		// A classe String do Java possui um método charAt(int index) que retorna um
		// char na posição indicada pelo parâmetro index.
		char letra = s.next().charAt(0);

		// Nesse exercício não era necessário fazer essa verificação, mas em um sistema
		// real, verificar se a letra inserida é válida é algo importante.
		// A classe Character possui diversos método para trabalhar com char (verificar
		// se é letra, dígito, conversão para maiúscula/minúscula, entre outros).
		if (!Character.isLetter(letra)) {
			System.err.println("A letra informada é inválida!");

			// System.exit() encerra a JVM. O parâmetro indica um código de status; por
			// convenção, um valor diferente de zero significa que o programa encerrou de
			// forma anormal (ex. erro).
			System.exit(1);
		}

		letra = Character.toLowerCase(letra);

		if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
			System.out.println("A letra informada é uma vogal.");
		} else {
			System.out.println("A letra informada é uma consoante.");
		}

		// Mesma operação do if/else acima, mas usando switch-case.
		switch (letra) {
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
				System.out.println("A letra informada é uma vogal.");
				break;
	
			default:
				System.out.println("A letra informada é uma consoante.");
				break;
		}
		
		// Mesma operação, mas usando "enhanced switch" com "arrow case" labels ao invés de "colon case" labels (Java 13+).
		// Observe que:
		// - É possível comparar a letra com diversos valores separados por vírgulas;
		// - Ao invés de dois pontos (:) após case <valor>, usamos a seta (->);
		// - Não há necessidade de incluir a instrução break; para que o switch seja executado corretamente.
		switch (letra) {
			case 'a', 'e', 'i', 'o', 'u' -> {
				System.out.println("A letra informada é uma vogal.");
			}
			default -> {
				System.out.println("A letra informada é uma consoante.");
			}
		}

		s.close();
	}

}
