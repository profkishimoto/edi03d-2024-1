//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 7
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 7. Escreva um método estático contarVogais() que recebe uma string como parâmetro
 * e retorna a quantidade de vogais encontradas na string.
 *
 * Inclua um código na main() que exemplifica o uso do método contarVogais().
 * 
 * Dicas:
 * - A classe String do Java possui um método charAt(int index) que
 * retorna um char na posição indicada pelo parâmetro index.
 * - A classe String do Java possui um método toCharArray() que retorna
 * o conteúdo da string como um array de chars.
 */

import java.util.Scanner;

public class Ex7 {

	public static int contarVogais(String str) {
		int contador = 0;

		// Usando for-each e enhanced switch.
		char strAsChar[] = str.toUpperCase().toCharArray();
		for (var c : strAsChar) {
			switch (c) {
				case 'A', 'E', 'I', 'O', 'U' -> {
					++contador;
				}
			}
		}

		// Usando for e switch-case tradicionais.
//		int tamanho = str.length();
//		for (int i = 0; i < tamanho; ++i) {
//			switch (Character.toUpperCase(str.charAt(i))) {
//			case 'A':
//			case 'E':
//			case 'I':
//			case 'O':
//			case 'U':
//				++contador;
//				break;
//			}
//		}
		
		return contador;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.print("Digite algo: ");
		String palavra = s.nextLine();

		int quantidadeVogais = contarVogais(palavra);
		System.out.println(palavra + " possui " + quantidadeVogais + " vogais.");

		s.close();
	}

}
