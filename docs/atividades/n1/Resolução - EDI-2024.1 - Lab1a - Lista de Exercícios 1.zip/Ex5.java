//
// Ciência da Computação - Estrutura de Dados I
// Lista de Exercícios 1 – Programação Java
// Exercício 5
// Copyright (C) 2024 André Kishimoto
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//

/*
 * 5. Escreva um método estático min() que recebe dois parâmetros numéricos inteiros
 * e retorna o menor valor entre eles e um método estático max() que recebe dois
 * parâmetros numéricos inteiros e retorna o maior valor entre eles.
 * 
 * Inclua um código na main() que exemplifica o uso dos dois métodos.
 */

import java.util.Scanner;

public class Ex5 {

	public static int min(int n1, int n2) {
		if (n1 < n2)
			return n1;
		else
			return n2;
	}

	public static int max(int n1, int n2) {
		return n1 > n2 ? n1 : n2;
		
		// O operador ternário ?: usado acima equivale a:
		// if (n1 > n2) return n1; else return n2;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);

		System.out.print("n1: ");
		int n1 = s.nextInt();

		System.out.print("n2: ");
		int n2 = s.nextInt();

		System.out.println("Menor entre " + n1 + " e " + n2 + ": " + min(n1, n2));
		System.out.println("Maior entre " + n1 + " e " + n2 + ": " + max(n1, n2));

		s.close();
	}

}
