import java.util.InputMismatchException;
import java.util.Scanner;

import edi.Pilha;

public class Program {
	
	public static String dec2bin(int numero) {
		Pilha p = new Pilha();
		while (numero > 0) {
			p.push(numero % 2);
			numero /= 2;
		}
		
		StringBuilder sb = new StringBuilder();
		while (!p.isEmpty()) {
			sb.append(p.pop());
		}
		
		return sb.toString();
	}

	public static void main(String[] args) {
		dec2bin(2024);
		
		Scanner scanner = new Scanner(System.in);
		String input = "";
		int numero = 0;
		boolean entradaValida = false;
		
		while (!entradaValida) {
			System.out.println("Informe um número: ");
			input = scanner.nextLine();

			try {
				numero = Integer.parseInt(input);
				entradaValida = true;
			} catch (NumberFormatException e) {
				System.out.println("Valor informado deve ser um número inteiro!");
				entradaValida = false;
			}
		}
		
		System.out.println("Número informado: " + numero);
		String binario = dec2bin(numero);
		System.out.println("Binário: " + binario);
	}

}
