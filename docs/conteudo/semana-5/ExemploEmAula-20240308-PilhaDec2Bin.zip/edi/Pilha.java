package edi;

public class Pilha {
	
	// Constante estática que pertence à classe Pilha.
	// Tudo que é marcado como static existe na memória sem ter
	// a necessidade de instanciar um objeto da classe.
	private static final int TAMANHO_PILHA = 16;
	
	// Vetor (array) de algum tipo.
	private int dados[];

	// Variável de controle que serve para:
	// - Contar elementos empilhados.
	// - Índice correto de um novo elemento na pilha.
	private int contador;
	
	// create(): cria e retorna uma pilha vazia com tamanho padrão TAMANHO_PILHA.
	public Pilha() {
		this(TAMANHO_PILHA);
	}
	
	// create(): cria e retorna uma pilha vazia com tamanho definido pelo parâmetro tamanho.
	public Pilha(int tamanho) {
		contador = 0;
		dados = new int[tamanho];
	}
	
	// push(): insere um elemento no topo da pilha.
	public void push(int valor) {
		// TODO: Tratar o caso em que a pilha está cheia.
		
		// A linha abaixo equivale às duas próximas linhas.
		//dados[contador++] = valor;

		dados[contador] = valor;
		++contador;
	}
	
	// pop(): remove e retorna o elemento do topo da pilha.
	public int pop() {
		// TODO: Tratar o caso em que a pilha está vazia.
		
		--contador;
		int topo = dados[contador];
		// "Liberar" o espaço do topo da pilha (que foi removido).
		// Se a pilha armazenasse objetos, faríamos uma atribuição dados[contador] = null;
		// Se fosse linguagem C e a pilha armazenasse algo alocado dinamicamente (com malloc ou calloc)
		// faríamos uma chamada à free(dados[contador]); dados[contador] = NULL;
		dados[contador] = 0; 
		
		return topo;
	}
	
	// top(): retorna o elemento do topo da pilha, sem removê-lo.
	public int top() {
		// TODO: Tratar o caso em que a pilha está vazia.
		
		return dados[contador - 1];
	}
	
	public boolean isEmpty() {
		return contador == 0;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("tamanho da pilha: " + dados.length + "\n");
		for (int i = 0; i < dados.length; ++i) {
			sb.append(dados[i]).append(", ");
		}
		return sb.toString();
	}

}








