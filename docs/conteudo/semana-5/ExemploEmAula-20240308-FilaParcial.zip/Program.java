import edi.Fila;

public class Program {

	public static void main(String[] args) {
		Fila f1 = new Fila(5);
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());
		
		f1.enqueue('A');
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

		f1.enqueue('B');
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

		f1.enqueue('C');
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

		char valor = f1.dequeue();
		System.out.println("Valor removido: " + valor);
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());
		
		f1.enqueue('D');
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

		f1.enqueue('E');
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

		f1.dequeue();
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

		f1.enqueue('F');
		System.out.println(f1);
		System.out.println("Primeiro da fila: " + f1.front());

	}

}
