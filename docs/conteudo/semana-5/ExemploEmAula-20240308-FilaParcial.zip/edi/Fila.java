package edi;

public class Fila {
	
	private static final int TAMANHO_FILA = 32;

	private char dados[];
	private int contador;
	private int primeiro;
	private int ultimo;
	
	public Fila() {
		this(TAMANHO_FILA);
	}
	
	public Fila(int tamanho) {
		contador = 0;
		primeiro = 0;
		ultimo = 0;
		dados = new char[tamanho];
	}
	
	public void enqueue(char valor) {
		// TODO: Tratar caso em que a fila está cheia.
		
		dados[ultimo] = valor;
		ultimo = (ultimo + 1) % dados.length;
		++contador;
	}
	
	public char dequeue() {
		// TODO: Tratar caso em que a fila está vazia.
		
		char valor = dados[primeiro];
		// "Liberar" o espaço do início da fila (que foi removido).
		// Se a fila armazenasse objetos, faríamos uma atribuição dados[primeiro] = null;
		dados[primeiro] = '\0';
		primeiro = (primeiro + 1) % dados.length;
		--contador;
		
		return valor;
	}
	
	public char front() {
		// TODO: Tratar caso em que a fila está vazia.
		
		return dados[primeiro];
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("tamanho da fila: " + dados.length + "\n");
		for (int i = 0; i < dados.length; ++i) {
			if (dados[i] == '\0') {
				sb.append("\\0");
			} else {
				sb.append(dados[i]);
			}
			sb.append(", ");
		}
		return sb.toString();
	}

}
