
public class Estudante {
	private String matricula;
	private String nome;
	private float n1;
	private float n2;
	private float sub;
	private float pf;
	
	Estudante() {
		this("?", "");
	}
	
	Estudante(String matricula, String nome) {
		this.matricula = matricula;
		this.nome = nome;
		n1 = n2 = sub = pf = 0.0f;
	}
	
	public void AtualizarN1(float nota) {
		if (nota != 99.9f && nota < 0.0f || nota > 10.0f)
			return;
		
		n1 = nota;
	}
	
	public void AtualizarN2(float nota) {
		if (nota != 99.9f && nota < 0.0f || nota > 10.0f)
			return;
		
		n2 = nota;
	}
	
	public void AtualizarSub(float nota) {
		if (nota != 99.9f && nota < 0.0f || nota > 10.0f)
			return;
		
		sub = nota;
	}
	
	public void AtualizarPF(float nota) {
		if (nota != 99.9f && nota < 0.0f || nota > 10.0f)
			return;

		pf = nota;
	}

	@Override
	public String toString() {
		return "MATRÍCULA: " + matricula + ", " + nome + ", " + n1 + ", "
				 + n2 + ", " + sub + ", " + pf;
	}
}
