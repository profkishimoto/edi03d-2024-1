
public class Program {

	public static void main(String[] args) {
		Estudante e1 = new Estudante();
		e1.AtualizarN2(-5.0f);
		
		e1.AtualizarN1(10.0f);
		e1.AtualizarN1(-2.0f);
		e1.AtualizarN1(20.0f);
		System.out.println("e1: " + e1);
		
		Estudante e2 = new Estudante("123", "Abc");
		System.out.println("e2: " + e2);
	}

}
