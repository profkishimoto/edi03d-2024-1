import edi.Pilha;

public class Program {

	public static void main(String[] args) {
		Pilha p = new Pilha();
		p.push(99);
		System.out.println("pilha: " + p);
		p.push(2000);
		System.out.println("pilha: " + p);
	}

}
