package edi;

public class Pilha {
	
	// Vetor (array) de algum tipo.
	private int dados[];

	// Variável de controle que serve para:
	// - Contar elementos empilhados.
	// - Índice correto de um novo elemento na pilha.
	private int contador;
	
	// create(): cria e retorna uma pilha vazia.
	public Pilha() {
		contador = 0;
		dados = new int[10];
	}
	
	// push(): insere um elemento no topo da pilha.
	public void push(int valor) {
		// A linha abaixo equivale às duas próximas linhas.
		//dados[contador++] = valor;

		dados[contador] = valor;
		++contador;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < dados.length; ++i) {
			sb.append(dados[i]).append(", ");
		}
		sb.append("\n");
		return sb.toString();
	}
}








